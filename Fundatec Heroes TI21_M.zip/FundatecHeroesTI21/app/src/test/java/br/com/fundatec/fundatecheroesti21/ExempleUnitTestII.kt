package br.com.fundatec.fundatecheroesti21

import org.junit.Assert
import org.junit.Test

class ExempleUnitTestII {
    @Test
    fun addition_isCorrect() {
        Assert.assertEquals(5, 3 + 2)
    }
}
