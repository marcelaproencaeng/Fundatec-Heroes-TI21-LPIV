package br.com.fundatec.fundatecheroesti21.profile.presentation.model

import br.com.fundatec.fundatecheroesti21.login.presentation.model.LoginViewState

sealed class ProfileViewState {
    object ShowNameErrorMessage : ProfileViewState()
    object ShowEmailErrorMessage : ProfileViewState()
    object ShowPasswordErrorMessage : ProfileViewState()
    object ShowRegisterErrorMessage : ProfileViewState()
    object ShowErrorMessage : ProfileViewState()
    object ShowHomeScreen : ProfileViewState()
    object ShowLoading : ProfileViewState()
}