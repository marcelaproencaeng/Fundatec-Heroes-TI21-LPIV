package br.com.fundatec.fundatecheroesti21.profile.presentation

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

import br.com.fundatec.fundatecheroesti21.profile.presentation.model.ProfileViewState

class ProfileViewModel : ViewModel() {
    private val viewS = MutableLiveData<ProfileViewState>()
    val s: LiveData<ProfileViewState> = viewS


    fun validateInputs(name: String?, email: String?, password: String?, register: String?) {
        viewS.value = ProfileViewState.ShowLoading
        if (name.isNullOrBlank() && email.isNullOrBlank() && password.isNullOrBlank() && register.isNullOrBlank()) {
            viewS.value = ProfileViewState.ShowErrorMessage
            return
        }
        if (name.isNullOrBlank()) {
            viewS.value = ProfileViewState.ShowNameErrorMessage
            return
        }
        if (email.isNullOrBlank()) {
            viewS.value = ProfileViewState.ShowEmailErrorMessage
            return
        }
        if (password.isNullOrBlank()) {
            viewS.value = ProfileViewState.ShowPasswordErrorMessage
            return
        }
        if (register.isNullOrBlank()) {
            viewS.value = ProfileViewState.ShowRegisterErrorMessage
            return
        }
        fetchLogin(name, email, password, register)
    }

    private fun fetchLogin(name: String, email: String, password: String, register: String) {
        viewS.value = ProfileViewState.ShowHomeScreen
    }
}
