package br.com.fundatec.fundatecheroesti21.dataBiding;

import androidx.databinding.ViewDataBinding;

public class ActivityMainBindingImpl extends ViewDataBinding {
}
