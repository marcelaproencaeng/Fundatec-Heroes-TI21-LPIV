package br.com.fundatec.fundatecheroesti21.home.presentation.model

sealed class HomeViewState {
}